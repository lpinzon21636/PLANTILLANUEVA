# ProyectoDEFINITIVO
Este sí es el proyecto final del corte

-> Primeros avances del proyecto, se establece la estructura básica de HTML5 y se vincula con la hoja de estilo CSS3.

-> Se establece la cabecera, e para separar la página en 3 secciones donde irá ubicada la información relacionada con el proyecto.

-> Se redactan los primeros comentarios en la hoja HTML para evidenciar las aplicaciones realizadas.

-> Se agregan las primeras clases de CSS3 para encerrar cajas de texto con sus diferentes atributos y propiedades para cumplir el esquema del MockUp

-> Fue agregado el Grid lateral y se solucionó el error para que los Grid de DOMÓTICA y BENEFICIOS quedaran paralelos el uno del otro.
