>README

-Fueron mejoradas las secciones existentes en el prototipo de la página

-fueron agregadas nuevas secciones

-Se agregó un NAVBAR que permite facilidad en la navegación entre páginas sin necesidad de volver al index

-fueron comentadas cada una de las diferentes modificaciones que se realizaron en la nueva página web

-Se organizó la codificación en CSS colocando todas las funciones en un único archivo llamado STYLES.CSS

-Fue agregado el nuevo README con los avances realizados hasta el momento

-Se agregó la licencia del MIT perteneciente al proyecto original

-Se organizó esquemáticamente cada uno de los archivos que hacen parte de la página web dentro de carpetas para generar orden

-El nuevo proyecto fue subido a GITHUB Para la posterior modificación de todo el equipo de trabajo