>README license

La implementación de la licencia MIT otorga la reutiliación de software dentro de software propietario. Asimismo, la licencia MIT tiene una alta compatibilidad con licencias copyleft, tales como General Public License GNU.

La licencia no cuenta con copyright, permitiendo su modificación. A su vez, esto puede llegar a ser contraproducente debido a que se puede alterar el contenido original de la versión. POr tal motivo, esta licencia es usada mayor parte de las veces en el Software libre.